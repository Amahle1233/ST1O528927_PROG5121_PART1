/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chartapp;

/**
 *
 * @author amahl
 */
public class MainApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
